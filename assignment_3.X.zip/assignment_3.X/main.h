#ifndef MAIN_H
#define	MAIN_H

#define LED1                RD0
#define LED2                RD1
#define LED3                RD2

#define LED_ARRAY1          PORTD
#define LED_ARRAY1_DDR      TRISD

#endif	/* MAIN_H */