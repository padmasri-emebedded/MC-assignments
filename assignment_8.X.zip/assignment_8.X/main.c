/*
 * File:   main.c
 * Author: padma
 *
 * Created on 21 March, 2025, 12:01 PM
 */


#include <xc.h>
#include "ssd.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF

static void init_config(void)
{
    init_ssd(); // initialization of  ssd 
    init_digital_keypad(); // initialization of digital keypad 
}

void main(void)
{
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    /*                          0    1    2      3     4     5    6      7      8     9 */
    unsigned int count = 0;
    unsigned int wait = 0;
    unsigned char key_1;
    unsigned char key_2;

    init_config(); 

    while (1) 
    {
        key_1 = read_digital_keypad(STATE); // key for state change 
        key_2 = read_digital_keypad(LEVEL); // key for level trigger 

        if (key_1 == SW1) //if state change, increment the count 
        {
            count++;

            if (count > 9999) //if count =9999, reset to 0 
            {
                count = 0;
            }
        }

        if (key_2== SW1) //if key is level triggered, increment the wait value 
        {
            wait++;
        }
        else
        {
            wait = 0; // reset wait to 0 
        }

        if (wait == 150) // when wait value reach 150 (which gives 2sec delay) 
        {
            count = 0; // reset the count to 0 
        }

        // display
        ssd[0] = digit[(count / 1000)];
        ssd[1] = digit[((count % 1000) / 100)];
        ssd[2] = digit[((count % 100) / 10)];
        ssd[3] = digit[(count % 10)];

        display(ssd);
    }

    return;
}