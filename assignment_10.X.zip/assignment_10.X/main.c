/*
 * File:   main.c
 * Author: padmasri
 *
 * Created on 26 February, 2025, 2:00 PM
 */


#include <xc.h>
#pragma config WDTE = OFF  
#include "ssd.h"
#include "digital_keypad.h"

void init_config()
{
    init_ssd();
    init_digital_keypad();
}

void main()
{
    unsigned char count = 0;
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char digits[12] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, BLANK, BLANK};
    unsigned char key;
    unsigned long int delay = 20;
    int flag = 0;  // 0 = Left Scroll, 1 = Right Scroll
    int flag_s = 1; // 1 = Running, 0 = Stopped

    init_config();
    // Initialize SSD display
    ssd[0] = ZERO;
    ssd[1] = ONE;
    ssd[2] = TWO;
    ssd[3] = THREE;

    while (1)
    {
        display(ssd); // Continuously refresh SSD

        key = read_digital_keypad(STATE);  // Read keypress state

        if (key == SW1)
        {
            flag = 0;  // Left scrolling
        }
        else if (key == SW2)
        {
            flag = 1;  // Right scrolling
        }
        else if (key == SW3)
        {
            flag_s = !flag_s; // Toggle stop/start
        }

        if (flag_s)  // If scrolling is not stopped
        {
            if(delay--==0)
            {
                delay=20;
            if (flag == 0)  // Left Scroll
            {
                count = (count + 1) % 12;  
            }
            else if (flag == 1)  // Right Scroll
            {
                if (count == 0)
                {
                    count = 11; 
                }
                else
                {
                    count--;  // Move right
                }
            }
            }
            ssd[0] = digits[(count) % 12];  
            ssd[1] = digits[(count + 1) % 12];
            ssd[2] = digits[(count + 2) % 12];
            ssd[3] = digits[(count + 3) % 12];  
        }
    }
}
