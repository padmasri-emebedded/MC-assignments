/*
 * File:   main.c
 * Author: padma
 *
 * Created on 22 March, 2025, 12:22 PM
 */


#include <xc.h>
#include "clcd.h"
#include <string.h>
#pragma config WDTE = OFF        

static void init_config(void) {
    init_clcd();
}

void main(void) {
    init_config();
    char data[]="good morning   ";
    int len = strlen(data);
    while (1) 
    {
        for(int i = len - 1;i > 0;i--)  //shift the data to right side
        {
            data[i] = data[i - 1];
        }
        data[0] = data[len-1];//put the data first of the string
        data[16] = 0;      
        clcd_print(data,LINE1(0)); // print the string
        for(unsigned long int wait = 100000;wait--;);  //delay
        }
    return;
}
