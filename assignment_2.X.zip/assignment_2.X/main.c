/*
 * File:   main.c
 * Author: padmasri
 *
 * Created on 19 February, 2025, 1:40 AM
 */

#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

void pattern1();
void pattern2();
void pattern3();
void pattern4();
int i=0;
static void init_config() 
{
    LED_ARRAY1_DDR = 0x00;
    
    LED_ARRAY1 = OFF;
    init_digital_keypad();
}

void main() {
    unsigned char key;
    unsigned long int delay= 5000; 
    init_config();
    int flag=0;
    while (1)
    {
        key = read_digital_keypad(STATE);
        if(key==SW1)
        {
            flag=1;
            PORTD=0x00;
        }
        else if(key==SW2)
        {
            flag=2;
            PORTD=0x00;
        }
        else if(key==SW3)
        {
            flag=3;
            PORTD=0x55;
        }
        else if(key==SW4)
        {
            flag=4;
            PORTD=0xF0;
        }
        if(delay--==0)
        {
            delay=5000;
            if(flag==1)
                pattern1();
            else if(flag==2)
                pattern2();
            else if(flag==3)
                pattern3();
            else if(flag==4)
                pattern4();
        }
    }
}
    void pattern1()
    {
        if (i < 8)  
            {
                PORTD = (PORTD << 1) | 1;  
                i++;
            }
            else if (i < 16)
            {
                PORTD = PORTD << 1;  
                i++;
            }
            else if (i < 24)
            {
                PORTD = (PORTD >> 1)|128;  
                i++;
            }
            else if (i < 32)
            {
                PORTD = PORTD >> 1;  
                i++;
            }
            else
            {
                i = 0;  
            }
    }
    void pattern2()
    {
      if (i < 8)  
            {
                PORTD = (PORTD << 1) | 1;  
                i++;
            }
            else if (i < 16)
            {
                PORTD = PORTD << 1;  
                i++;
            }  
            else 
                i=0;
    }
    void pattern3()
    {
        PORTD=~PORTD;
    }
    void pattern4()
    {
        PORTD=~PORTD;
    }
