#include <xc.h>
#include "main.h"
extern unsigned char duty_cycle;
unsigned char  loop_counter=0;

void __interrupt() isr(void)
{
    
    if (TMR0IF == 1)
    {
        if(loop_counter<=duty_cycle)
        {
            LED1=ON;
        }
        else
            LED1=OFF;
        loop_counter++;
        if(loop_counter==PERIOD)
            loop_counter=0;
        //loop_counter++;
        TMR0IF=0;      
    }
}