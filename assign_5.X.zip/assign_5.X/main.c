/*
 * File:   main.c
 * Author: padma
 *
 * Created on 19 March, 2025, 12:35 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#include "main.h"
#include "timers.h"

#pragma config WDTE=OFF
unsigned char duty_cycle=50;//he LED should glow with 50% Duty Cycle

void init_config()
{
    LED_ARRAY1 =0x00;//initialization of ports
    LED_ARRAY1_DDR  =0x00;
    init_timer0();//initialization of timer 0
    init_digital_keypad();//initialization of digital keypad
    GIE=1;//initialization of global interrupt
    PEIE=1;
}

void main(void)
{
    unsigned char key;
    unsigned long int wait=0;
    init_config();
    while(1)
    {
        key=read_digital_keypad(LEVEL);
        if(wait==0)
        {
            wait=2500;
        if(key==SW1&&duty_cycle !=PERIOD)
        {
            //duty cycle increased
            duty_cycle++;
            
        }
        else if(key==SW2 &&duty_cycle !=0)
        {
            //duty cycle decreased
            duty_cycle--;
        }
            
            
        }
    }
    return;
}
