#include <xc.h>

void init_timer0(void)
{
    /* Setting the internal clock source */
    T0CS = 0;
    
    /* Assinging the prescaler to watchdog timer */
    PSA = 1;    
    /* The timer interrupt is enabled */
    TMR0IE = 1;
    TMR0IF=0;
    //INTCON |=0xA0;
}
