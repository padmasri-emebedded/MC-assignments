/*
 * File:   main.c
 * Author: padma
 *
 * Created on 21 March, 2025, 4:12 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#include "main.h"
#include "timers.h"

#pragma config WDTE = OFF

unsigned short duty_cycle=10;
unsigned short sec = 5; 

static void init_config(void)
{
    
    LED_ARRAY1 = 0x00;
    LED_ARRAY1_DDR = 0x00;

    init_timer0(); // initializing timer0 
    init_digital_keypad(); // initializing digital keypad 
    GIE = 1;//enable the global interrupt
    
}

void software_pwm()
{
    static unsigned char loop_counter;

    if (loop_counter < duty_cycle)
    {
        LED1 = ON;
    }
    else
    {
        LED1 = OFF;
    }
    loop_counter++;
    if (loop_counter == PERIOD)
    {
        loop_counter = 0;
    }

    
}

void main(void)
{
    unsigned char key; 

    init_config();

    while (1) /*super loop */
    {
        key = read_digital_keypad(STATE); //read key press

        if (key == SW1) //if SW1 is pressed 
        {
            sec = 0; // reset seconds 
        }
        if (sec < 5) // if sec is less than 5, set duty cycle as 100% 
        {
            duty_cycle = 100;
   
        }
        else // set duty cycle is 10% 
        {
            duty_cycle = 10;
        }
        

        software_pwm(); //for controlling the LED brightness 
    }

    return;
}
