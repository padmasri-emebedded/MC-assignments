
#ifndef MAIN_H
#define	MAIN_H

#define LED1                RD0
#define PERIOD              100
#define ON                  1
#define OFF                 0
#define LED_ARRAY1          PORTD
#define LED_ARRAY1_DDR      TRISD

#endif	/* MAIN_H */

