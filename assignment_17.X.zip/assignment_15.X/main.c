/*
 * File:   main.c
 * Author: padmasri
 *
 * Created on 27 February, 2025, 3:36 AM
 */


#include <xc.h>

#pragma config WDTE = OFF   // Watchdog Timer disabled

#include "ssd.h"

void init_config()
{
    TRISB7 = 0;  // Set LED pin as output
    RB7 = 0;     // Initially turn OFF LED

    TRISB0 = 1;  // Set switch (INT0) as input

    // Interrupt configuration
    //INTEDG = 1;  // Interrupt on Rising Edge
    INTE = 1;    // Enable INT0 external interrupt
    GIE = 1;     // Enable global interrupts

    init_ssd();  // Initialize SSD
}

unsigned char count = 0;  

void main(void)
{
    unsigned char ssd[MAX_SSD_CNT] = {ONE, TWO, THREE, FOUR};  
    unsigned long int delay = 50;  // Delay counter

    init_config();  // Initialize all configurations

    while (1)
    {
        display(ssd);  // Show "1234" on SSD

        if (delay-- == 0)
        {
            delay = 50;
            RB7= !RB7;  // Toggle LED every second
            count++;

        if (count == 5)  // Sleep condition
        {
            SLEEP();
        }
        }
    }
}

// Interrupt Service Routine (ISR)
void __interrupt() isr()
{
    if (INTF == 1)  // Check if INT0 triggered
    {
        count = 0;   // Reset counter
        INTF = 0;    // Clear interrupt flag
    }
}
