#include <xc.h>

void init_timer0(void) /* Timer0 Module */
{
    T0CS = 0; /* Setting the internal clock source */

    PSA = 1; /* Assigning the prescaler to Watchdog Timer */

    TMR0 = 6; /* Preloading TMR0 with 256 - 250 = 6 */

    TMR0IE = 1; /* The timer interrupt is enabled */
}

void init_timer1(void) /* Timer1 Module */
{
    /*Enable the timer1*/
    TMR1ON = 1;
    
    /*Enable the pre scale bit 1:8*/
    T1CKPS1 = 1;
    T1CKPS0 = 0;

    TMR1H = 0x0B;
    TMR1L = 0xDC;
    
       
    /*Enable the timer1 bit*/
    TMR1IE = 1;
}

void init_timer2(void) /* Timer2 Module */
{/*selecting scale as 1:4*/
    T2CKPS0 = 1;
    T2CKPS1 = 0;
    
    /*The timer interrupt is enabled*/
    
    TMR2IE = 1;
    
  
   
    /*Loading the pre load register as 250*/
    PR2 = 250;
    /*Switching on timer 2*/
    TMR2ON = 1;
}
