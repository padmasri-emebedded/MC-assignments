/*
 * File:   main.c
 * Author: padma
 *
 * Created on 20 March, 2025, 3:02 PM
 */


#include <xc.h>
#include "main.h"
#include "timer.h"

/* Watchdog Timer Enable bit (WDT disabled) */
#pragma config WDTE = OFF
static void init_config(void)
{
    LED_ARRAY1_DDR = 0x00; 
    LED_ARRAY1 = 0x00; 

    /* initialization of Timers */
    init_timer0();
    init_timer1();
    init_timer2();

    PEIE = 1; /* Peripheral Interrupt Enable Bit (For Timer2) */
    GIE = 1; /* Enable all the Global Interrupts */
}

void main(void)
{
    init_config(); /* function call */

    while (1) 
    {
        ;
    }
    return;
}