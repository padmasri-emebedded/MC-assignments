/*
 * File:   main.c
 * Author: padma
 *
 * Created on 18 February, 2025, 11:51 AM
 */


#include <xc.h>

#pragma config WDTE = OFF  

void init_config()
{
    // Set PORTD as output for LEDs
    TRISD = 0x00;
    // Initially turn off LEDs
    PORTD = 0x00; 
    // Set switch as input
    TRISB0 = 1;  
}

void main() 
{
    init_config();
    int i = 0;
    unsigned long int wait = 5000;  

    while (1)
    {
        if (wait-- == 0)  
        {
            wait = 5000;  
            if (i < 8)  
            {
                PORTD = (PORTD << 1) | 1;  
                i++;
            }
            else if (i < 16)
            {
                PORTD = PORTD << 1;  
                i++;
            }
            else if (i < 24)
            {
                PORTD = (PORTD >> 1)|128;  
                i++;
            }
            else if (i < 32)
            {
                PORTD = PORTD >> 1;  
                i++;
            }
            else
            {
                i = 0;  
            }
        }
    }
}

