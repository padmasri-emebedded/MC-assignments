/*
 * File:   main.c
 * Author: padmasri
 *
 * Created on 20 February, 2025, 2:42 AM
 */


#include <xc.h>
#include "ssd.h"

#pragma config WDTE = OFF  

void init_config()
{
    init_ssd();
}

void main()
{
    unsigned char count = 0;
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char digits[12] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, BLANK, BLANK};
    
    unsigned long int delay = 10;

    init_config();

    ssd[0] = ZERO;
    ssd[1] = ONE;
    ssd[2] = TWO;
    ssd[3] = THREE;
    
    while (1)
    {
        display(ssd);

        if (delay--==0) 
        {
            delay= 10;  
            
            count++;  
            if (count == 12) 
            {
                count = 0;
            }

            ssd[0] = digits[(count) % 12];  
            ssd[1] = digits[(count + 1) % 12];
            ssd[2] = digits[(count + 2) % 12];
            ssd[3] = digits[(count + 3) % 12];  
        }
    }
}
