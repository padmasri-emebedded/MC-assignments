/*
 * File:   main.c
 * Author: padma
 *
 * Created on 28 March, 2025, 8:21 PM
 */


#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#pragma config WDTE = OFF

unsigned char pos = 4; // position in clcd 
static void init_config(void)
{
    init_clcd(); // initialization of clcd
    init_matrix_keypad(); // initialization of matrix keypad 
}

void main(void)
{
    int num = 0; 
    unsigned char key, key_copy;
    unsigned char temp;
    unsigned char previous_direction; // to store the previous direction while scrolling is paused 
    unsigned short index = 0; //msg[]
    char msg[16] = "                "; //message to display
    char msg_buff[16] = "                "; //message backup 
    unsigned short edit_mode_flag = 1; //default edit mode
    unsigned short pause_flag = 0; //scrolling
    unsigned short first_iter_flag = 1; //iteration
    static unsigned char toggle_cursor = 0;
    static unsigned int blink_delay = 0;
    
    init_config(); 


    while (1) 
    {
        key = read_matrix_keypad(STATE); 

        if (key != ALL_RELEASED) // when S1 or S2 is pressed
        {
            key_copy = key; //storing the value of key in key_copy 
        }
        if (blink_delay++ == 2)//cursor blinking
        {
            blink_delay = 0;
            toggle_cursor = !toggle_cursor;
        }

        if (edit_mode_flag == 1)//edit mode
        {
            clcd_print("Enter number", LINE1(0));
            clcd_print("Num:", LINE2(0));
            switch (toggle_cursor)
            {
                case 0:
                    clcd_putch((unsigned char) 0xFF, LINE2(pos));
                    break;
                case 1:
                    clcd_print(msg, LINE2(4));
                    break;
            }

            if (first_iter_flag == 1) // if 1st time iteration==1, load with 0 
            {
                msg[index] = (char) num + '0';
            }
            if (key == 1) //increment the num value 
            {
                num++;

                if (num > 9) 
                {
                    num = 0;
                }

                msg[index] = (char) num + '0'; //storinf the value
                clcd_putch((char) num + '0', (unsigned char) LINE2(pos)); // displaying the number in clcd 
            }

            else if (key == 2) // decrement the num value 
            {
                num--;

                if (num < 0) //roll over 
                {
                    num = 9;
                }

                msg[index] = (char) num + '0'; //storinf the value
                clcd_putch((char) num + '0', (unsigned char) LINE2(pos)); //displaying the number in clcd 
            }

            else if (key == 3) //start scrolling 
            {
                clcd_print("                ", LINE1(0));
                clcd_print("                ", LINE2(0));

                key_copy = 2; //right scrolling

                previous_direction = key_copy; //direction store

                for (int i = 0; i < 16; i++) //copying msg
                {
                    msg_buff[i] = msg[i];
                }

                first_iter_flag = 0; //first iteration is completed
                edit_mode_flag = 0; //edit mode off
            }

            else if (key == 5)//increase the position
            {
                if (pos < 15)
                {
                    num = 0; //default value set to 0 
                    pos++; //incrementing the position 
                    index++; //incrementing the index 

                    msg[index] = (char) num + '0'; //storing the value
                    clcd_putch((char) num + '0', (unsigned char) LINE2(pos)); //display in clcd
                }
            }

            else if (key == 6) //backspace remove last one
            {
                if (pos > 4 && pos < 16)
                {
                    clcd_putch(' ', (unsigned char) LINE2(pos)); //displaying the deleted number
                    msg[index] = ' '; //eplacing the deleted number 

                    num = msg[index - 1] - 48; //loading num with previous position number value 
                    pos--; // decrementing the position 
                    index--; //decrementing the index 
                }
            }
        }

        else //scroll mode
        {
            if (key_copy == 1) //left direction
            {
                previous_direction = key_copy; //directiion store
                temp = msg[0];//diection towards left

                for (unsigned int i = 0; i < 16; i++)
                {
                    msg[i] = msg[i + 1];
                }

                msg[15] = temp;

                clcd_print(msg, LINE2(0)); 
                for (unsigned int j = 50000; j--;); //delay
            }

            else if (key_copy == 2) //right direction
            {
                previous_direction = key_copy; //diection store
                temp = msg[15];

                for (unsigned int i = 15; i > 0; i--)
                {
                    msg[i] = msg[i - 1];
                }

                msg[0] = temp;

                clcd_print(msg, LINE2(0));
                for (unsigned int j = 50000; j--;); //delay
            }

            else if (key_copy == 3) //pause
            {
                pause_flag = !pause_flag; //toggle

                if (pause_flag == 1) // pause 
                {
                    key_copy = ' '; 
                }
                else // scroll
                {
                    key_copy = previous_direction; 
                }
            }

            else if (key_copy == 4) //edit mode
            {
                for (int i = 0; i < 16; i++)
                {
                    msg[i] = msg_buff[i];
                }

                edit_mode_flag = 1; 
            }
            else if (key_copy == ' ') 
            {
                ; 
            }

            else //any key is pressed
            {
                key_copy = previous_direction; 
            }
        }
    }

    return;
}