#include<xc.h>
#include"main.h"
void __interrupt() isr(void)
{
    static unsigned short value;
    static unsigned int wait = 0;
    if(TMR2IF == 1)       //check the interrupt flag enabled or not
    {
        if(!wait--)
        {
            wait = 500;
        
            duty_cycle = adc_reg_val;
            if (duty_cycle > value)//increase a brightness  
            {
                value = duty_cycle;
                if(duty_cycle != PERIOD)
                {
                duty_cycle ++;
                }
            }
            else if (duty_cycle < value)
            {
                value = duty_cycle;
                if(duty_cycle != 0)
                {
                // Decrease brightness 
                duty_cycle--;
                }
            }
        }
        if(loop_counter <= duty_cycle)//check the loop_count less than duty_cycle
        {
            LED1 = ON;
        }
        else
        {
            LED1 = OFF;
        }
        if(loop_counter == PERIOD)
        {
            loop_counter = 0;
        }
        loop_counter++;
       TMR2IF = 0;   
    }
}