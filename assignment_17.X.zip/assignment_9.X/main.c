/*
 * File:   main.c
 * Author: padma
 *
 * Created on 28 March, 2025, 2:01 PM
 */


#include <xc.h>
#include "clcd.h"
#include "adc.h"
#pragma config WDTE = OFF

void display(unsigned short data) //clcd display
{
    char buff[3];
    int i = 1;
    do
    {
        buff[i] = (data % 10) + '0';
        data = data / 10;

    } while (i--);

    buff[2] = '\0'; //add null at end

    clcd_print("TEMPERATURE: ", LINE2(0));
    clcd_print(buff, LINE2(12));
    clcd_putch(0xDF, LINE2(14));
    clcd_putch('C', LINE2(15));
}
static void init_config(void)
{
    init_clcd(); //initilaization of clcd
    init_adc(); //initialization of adc
}

void main(void)
{
    unsigned short analog_value; //0 to 1023
    unsigned short temperature;

    init_config(); 

    clcd_print("LM35 TEMP SENSOR", LINE1(0));
    
    while (1) 
    {
        analog_value = read_adc(CHANNEL2); //10 bits -> 0 to 1023
        temperature = (unsigned short) ((analog_value * 4.8828125) / 10);

        display(temperature);
    }

    return;
}
