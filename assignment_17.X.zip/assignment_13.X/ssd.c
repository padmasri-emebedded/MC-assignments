/*
 * File:   ssd.c
 * Author: sathi
 *
 * Created on 20 February, 2025, 12:16 AM
 */


#include <xc.h>
#include "ssd.h"

void init_ssd(void)
{
    /* Seeting the SSD data line as Output */
    SSD_DATA_PORT_DDR = 0x00;
    
    /* Setting SSD Control Line as Output (RA5 - RA2) */
    SSD_CONTROL_PORT_DDR = SSD_CONTROL_PORT_DDR & 0x03;
    
    //initially turn off all ssd
    SSD_CONTROL_PORT = SSD_CONTROL_PORT & 0x03;
}

void display(unsigned char data[])
{
    unsigned char digit;
    
    for (digit = 0; digit < MAX_SSD_CNT; digit++)
    {
           //assign data to the data port
        SSD_DATA_PORT = data[digit];
        
        //turn on 1 ssd
        SSD_CONTROL_PORT = (SSD_CONTROL_PORT & 0x03) | (0x04 << digit);
        
        //small delay
       for (unsigned long int wait = 1000; wait--; );
    }
}