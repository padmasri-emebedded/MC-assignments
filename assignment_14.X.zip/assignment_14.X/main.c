/*
 * File:   main.c
 * Author: padma
 *
 * Created on 24 March, 2025, 12:50 PM
 */


#include <xc.h>
#include "ssd.h"
#include "digital_keypad.h"
#include "i2c.h"
#include "EEprom.h"
#pragma config WDTE = OFF
unsigned int count;
static void init_config(void)
{
    init_ssd(); //initialization of ssd 
    init_digital_keypad(); // initialization of digital keypad 
    init_i2c(100000); //initialization of i2c protocol 
    count = (ext_eeprom_24C02_read(0x01) * 100) +ext_eeprom_24C02_read(0x00);//saved data into count
}

void main(void)
{
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    unsigned char wait = 0;
    unsigned char key_1;
    unsigned char key_2;

    init_config(); 

    while (1) 
    {
        key_1 = read_digital_keypad(STATE); //key for state change 
        key_2 = read_digital_keypad(LEVEL); // key for level trigger 

        if (key_1 == SW1) //increment the count 
        {
            count++;

            if (count > 9999)//if count value reaches 9999, reset to 0
            {
                count = 0;
            }
        }

        if (key_2 == SW1) //if level triggered, increment the wait value 
        {
            wait++;
        }
        else
        {
            wait = 0;
        }

        if (wait == 150) //when wait value reach 150 (which gives 2sec)
        {
            count = 0;
        }

        if (key_1== SW2) //SW2 -> write count value to EEPROM 
        {
            ext_eeprom_24C02_byte_write(0x00, (count % 100)); //writing LSBs to 0x00 
            ext_eeprom_24C02_byte_write(0x01, (unsigned char) (count / 100)); //writing MSBs to 0x01 
        }

        //display
        ssd[0] = digit[(count / 1000)];
        ssd[1] = digit[((count % 1000) / 100)];
        ssd[2] = digit[((count % 100) / 10)];
        ssd[3] = digit[(count % 10)];

        display(ssd);
    }

    return;
}